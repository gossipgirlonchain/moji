# Handoff: moji social post templates

## Overview
Six square (1200×1200) social post templates for **moji** (moji.wtf), an emoji token launcher. They cover the recurring posts the product needs to publish: announcements, newly claimed pairs, a leaderboard, unclaimed ("still open") emoji, a weekly claim roundup, and a single big statistic.

The intended end state is a **render service inside moji.wtf**: real product data in, a 1200×1200 PNG/JPG out, ready to post to social. Each template is a layout with named slots; nothing about the design requires hand placement except the decorative emoji scatter, which should be generated (see "Emoji scatter" below).

## About the design files
`moji Social Templates.dc.html` in this bundle is a **design reference created in HTML** — a prototype showing the intended look, not production code to copy directly. The task is to recreate these layouts in the target codebase's environment using its established patterns. If no environment exists yet, pick the appropriate stack; for an image-render service the common choice is a headless-browser or Satori-style HTML/CSS renderer (React component per template → PNG at 1200×1200, 2× device scale factor for crispness).

All six artboards live on one canvas in the reference file, laid out in a wrapping flex row with 140px gaps and 140px padding on a #CFE6F5 page background. **The page background and the "01 · announcement" captions between boards are scaffolding for review only — they are not part of any post.** Each post is the 1200×1200 rounded rectangle.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii and shadows are final. Recreate pixel-for-pixel. The only intentionally loose element is the emoji scatter, which is meant to vary per post.

---

## Shared anatomy (every template)

### Artboard
- 1200 × 1200px, `overflow: hidden`, `border-radius: 48px` (the radius is a preview nicety; a square export is fine — but keep the overflow clip, the corner emoji bleed off the edge and rely on it)
- Background: `radial-gradient(120% 120% at 0% 0%, #EEF8FE 0%, #DCEEFB 58%, #DCEEFB 100%)` — a soft lift to near-white from the top left over --sky-100. This is the **only** gradient allowed in the system.

### Clay card
- `position: absolute; inset: 80px` → 1040 × 1040
- `border-radius: 32px`
- Background: `#FFFFFF` (templates 1, 3, 4, 5) or `#F2FAFF` / --sky-50 (templates 2, 6)
- Shadow (--clay): `8px 8px 24px rgba(18,64,92,.15), inset -8px -8px 16px rgba(18,64,92,.10), inset 8px 8px 16px rgba(255,255,255,.45)`
- `padding: 88px`, `display: flex; flex-direction: column`
- Content area is `flex: 1`; the footer row sits below it

### Footer row (inside the card, bottom)
- `display: flex; align-items: flex-end; justify-content: space-between; gap: 24px`
- Left: `moji` — Fredoka 600, 40px, #2E8BC9, `line-height: 1`, always lowercase
- Right: `moji.wtf` — Nunito 800, 24px, #5A8AA6, `line-height: 1`

### Text zone
The central content area must stay free of decoration so copy can be swapped without the layout breaking. No emoji, rules, or ornaments inside it; no scatter emoji within 80px of it.

---

## Emoji scatter (the signature of the system)

6–10 emoji placed around the outer edge of the **artboard**, in the 80px band outside the clay card, or bleeding off/overlapping only the card's corners. Rules, all hard:

1. 🍎 is **always** present, is **always the largest** emoji on the artboard, and sits either top-left or bottom-right.
2. Sizes 40–120px (the corner 🍎 runs 118–126px in the reference; treat ~126 as the ceiling).
3. Each emoji rotated between −18° and +18°.
4. Each emoji gets a soft drop shadow so it reads as clay, not a pasted sticker: `filter: drop-shadow(5px 6px 9px rgba(18,64,92,.24))` for small ones, scaling to `drop-shadow(7px 9px 11px rgba(18,64,92,.26))` for the large 🍎.
5. Never within 80px of the text zone; never overlapping a headline, a number, or the wordmark. **The specific failure to guard against:** the card's padding puts `moji.wtf` at roughly x 940–1032, y 1020–1044. Bottom-right scatter emoji must therefore start at `left ≥ 1060` / `top ≥ 1060`.
6. Loose and hand-placed, never a grid or an even ring.
7. Vary the set per post. Draw from: 🍎 🪟 🍕 ☕ 🪙 🔮 📦 🩹 🧇 🎢 🏠 💊 ☁️ 💾 ✈️ 🔍 💻 ⚡ 🚀 🌙 🐕

### Generating it
Implement as a seeded placement function so a given post always renders the same scatter:

- Take a seed (post id or pair ticker), pick 6–8 emoji from the pool, always including 🍎.
- Place 🍎 at the top-left (`left ≈ 14–22, top ≈ 16–26`) or bottom-right (`left ≈ 1062–1070, top ≈ 1060–1068`) corner slot, size 118–126.
- Fill remaining slots from: top-left corner, top edge, top-right corner, right edge, bottom-right corner, bottom edge, left edge, bottom-left corner — skipping the slot 🍎 took, and skipping a random one or two so the ring stays uneven.
- Slot position ranges observed in the reference (left / top, size range):
  - top-left corner: 14–22 / 16–26, 80–124
  - top edge: 400–600 / 2–8, 54–62
  - top-right corner: 1052–1068 / 20–32, 76–86
  - right edge: 1120–1130 / 350–680, 60–68
  - bottom-right corner: 1062–1070 / 1060–1068, 86–126
  - bottom edge: 318–560 / 1126–1132, 54–60
  - left edge: 2–6 / 460–690, 64–72
  - bottom-left corner: 20–26 / 1036–1040, 74–78
- Rotate each ±18°, jitter position within its range, and enforce the footer keep-out from rule 5.

Scatter lives in a `position: absolute; inset: 0; z-index: 3; pointer-events: none` overlay above the card.

---

## The six templates

### 1. Announcement
- **Purpose:** a single broadcast message.
- **Layout:** content column centered both axes, `gap: 36px`, `padding: 0 40px`.
- **Headline:** Fredoka 600, 132px, `line-height: 1.02`, #12405C, `text-align: center`, `text-wrap: balance`, tabular numerals. Up to 8 words. Reduce size for longer copy rather than letting it wrap past 3 lines.
- **Subline (optional):** Nunito 800, 44px, #5A8AA6, centered.
- **Card:** #FFFFFF.
- **Reference copy:** "creators earn on every trade" / "moji.wtf"
- **Slots:** `headline`, `subline?`

### 2. Pair card
- **Purpose:** announce a newly claimed emoji/ticker pair.
- **Layout:** centered column, `gap: 44px`.
- **Pill:** `padding: 20px 40px`, `border-radius: 999px`, background #FFFFFF, shadow --clay-sm (`4px 4px 14px rgba(18,64,92,.13), inset -4px -4px 10px rgba(18,64,92,.09), inset 4px 4px 10px rgba(255,255,255,.50)`). Text: Nunito 800, 28px, `letter-spacing: .16em`, #5FD3AE, uppercase — "JUST CLAIMED".
- **Hero emoji:** 300px, `line-height: 1`, `filter: drop-shadow(10px 14px 18px rgba(18,64,92,.24))`.
- **Pair notation:** Fredoka 600, 92px, #12405C, tabular numerals — "🍎 / \$AAPL". Must stay on one line; shrink if the ticker is long.
- **Card:** #F2FAFF.
- **Slots:** `label`, `emoji`, `ticker`

### 3. Leaderboard
- **Purpose:** top-earning pairs.
- **Header:** "top earners" — Fredoka 600, 76px, #12405C, left-aligned, at the top of the card.
- **Rows:** three, in a `flex: 1` column centered vertically. Each row `display: grid; grid-template-columns: 140px 1fr auto; align-items: center; gap: 32px; padding: 36px 0`.
  - Emoji: 96px (84px when the cell holds two emoji), `filter: drop-shadow(6px 8px 10px rgba(18,64,92,.22))`
  - Ticker: Fredoka 600, 60px, #12405C, tabular numerals
  - Figure: Fredoka 600, 60px, **#5FD3AE**, tabular numerals
- **Rules between rows:** `height: 10px; border-radius: 20px; background: #DCEEFB` — thick soft bars, never hairlines. Two rules for three rows; no rule above the first or below the last.
- **Card:** #FFFFFF.
- **Reference data:** 🐕 / \$NVDA \$4,120 · 🍕 / \$DPZ \$2,884 · 🚀🌙 / \$SPCE \$1,207
- **Slots:** `header`, `rows[3] = {emoji, ticker, amount}`

### 4. Still open
- **Purpose:** unclaimed emoji, as an invitation. These are the subject of the post and are separate from the scatter.
- **Header:** "still open" — Fredoka 600, 76px, #12405C, left-aligned.
- **Row:** `flex: 1`, `display: flex; align-items: center; justify-content: space-between; gap: 20px` — 6 to 8 items evenly spaced across the card.
- **Each item:** column, `align-items: center; gap: 22px`
  - Clay circle: 132 × 132, `border-radius: 999px`, background #F2FAFF, shadow --clay-sm, emoji centered at 72px
  - Ticker beneath: Fredoka 600, 32px, `line-height: 1`, #12405C, tabular numerals
- **Card:** #FFFFFF.
- **Reference data:** 🦖 \$DINO · 🧊 \$ICE · 🪝 \$HOOK · 🫧 \$BUBL · 🛼 \$ROLL · 🧲 \$MAG
- **Slots:** `header`, `items[6–8] = {emoji, ticker}`. At 8 items, drop the circle to ~118px and the gap to ~14px rather than letting the row overflow.

### 5. Claimed this week
- **Purpose:** weekly roundup with a total.
- **Header:** "claimed this week" — Fredoka 600, 76px, #12405C, left-aligned.
- **Grid:** `display: grid; grid-template-columns: repeat(5, 1fr); gap: 24px` — 10 tiles (8–12 acceptable; use 4 or 5 columns to keep rows full).
  - Tile: `border-radius: 24px`, background #F2FAFF, shadow --clay-sm, `padding: 22px 12px`, column, centered, `gap: 10px`
  - Emoji 52px; ticker Nunito 800, 22px, #5A8AA6, tabular numerals
- **Count:** Fredoka 600, 96px, #12405C, tabular numerals — "1,842 claimed". `gap: 48px` between grid and count; both in a `flex: 1` column centered vertically. Thousands separators required.
- **Card:** #FFFFFF.
- **Slots:** `header`, `tiles[8–12] = {emoji, ticker}`, `count`

### 6. Big number
- **Purpose:** one statistic.
- **Layout:** centered column, `gap: 24px`.
- **Pair above:** Fredoka 600, 64px, #2E8BC9, tabular numerals — "🧇 / \$TSM"
- **Figure:** Fredoka 600, 300px, `line-height: 1`, #12405C, `letter-spacing: -.02em`, tabular numerals — "+340%". Step down to ~240px for 6+ characters.
- **Label beneath:** Nunito 800, 44px, #5A8AA6 — "this week"
- **Card:** #F2FAFF.
- **Slots:** `pair`, `figure`, `label`

---

## Interactions & behavior
The templates are static export artwork — no hover, focus, or animation states, and no responsive breakpoints (the output is always 1200×1200). Behavior lives in whatever admin UI you build around them:

- Pick a template, fill its slots from product data, preview, export PNG.
- Seeded scatter means the same post regenerates identically; expose a "reshuffle" that bumps the seed.
- Overflow is the one real edge case: long tickers, 4+ digit figures, and long headlines all need the step-down rules noted per template. Validate slot lengths on input rather than letting text wrap unexpectedly.

## State management
For a render service, none per template — they are pure functions of `(slots, seed) → markup`. An admin UI needs: selected template, slot values, scatter seed, and export status (idle / rendering / done / error).

## Design tokens
```
--sky-50:  #F2FAFF      --ink:      #12405C
--sky-100: #DCEEFB      --ink-soft: #5A8AA6
--sky-200: #C3E3F8      --mint:     #5FD3AE
--sky-300: #9BD2F4      --coral:    #FF9E9E
--sky-400: #6FBDEE
--sky-500: #4AA8E6
--sky-600: #2E8BC9

--clay:    8px 8px 24px rgba(18,64,92,.15),
           inset -8px -8px 16px rgba(18,64,92,.10),
           inset 8px 8px 16px rgba(255,255,255,.45)
--clay-sm: 4px 4px 14px rgba(18,64,92,.13),
           inset -4px -4px 10px rgba(18,64,92,.09),
           inset 4px 4px 10px rgba(255,255,255,.50)
```

- `--sky-200` through `--sky-500` and `--coral` are reserved headroom; the six reference templates don't use them.
- **Radii:** 48 (artboard), 32 (card), 24 (tile), 999 (pill, circle). **Minimum radius anywhere is 20px — no sharp corners.**
- **Spacing:** 80 (artboard inset), 88 (card padding), 48, 44, 36, 32, 24, 22, 20, 10.
- **Type:** Fredoka 600 for headlines, headers, pair notation and all numerals. Nunito 800 for sublines and labels. Never below 600 weight. Headlines get `text-wrap: balance`; all numerals get `font-variant-numeric: tabular-nums`. Scale: 300, 132, 96, 92, 76, 72, 64, 60, 52, 44, 40, 32, 28, 24, 22.
- **Constraints to preserve:** no gradients other than the background lift (and a --mint fill under a chart, if one is ever added); no drop shadows on text; no photography, illustration, or 3D — the emoji are the only imagery; nothing centered except where specified — headlines center, structural content aligns left.

## Assets
### Fonts
Google Fonts. `https://fonts.googleapis.com/css2?family=Fredoka:wght@300..700&family=Nunito:wght@600;700;800&display=swap`. Self-host both for a render service so exports don't depend on a network fetch.

### Emoji
**This is the one real implementation decision.** The reference file uses the system emoji font (`'Apple Color Emoji','Segoe UI Emoji','Noto Color Emoji'`), so glyphs look different on every OS — a headless renderer on Linux will not match the macOS preview. For consistent output, pick one emoji set and ship it with the renderer:

- **Noto Color Emoji** as a bundled font (simplest; keeps emoji as text, so sizing and `drop-shadow` work unchanged), or
- an SVG/PNG emoji set (Noto, Twemoji, OpenMoji) drawn as `<img>`, which gives sharper large glyphs at 300px but means replacing the text spans with images and re-checking the drop shadows.

Either way, verify the full pool renders: 🍎 🪟 🍕 ☕ 🪙 🔮 📦 🩹 🧇 🎢 🏠 💊 ☁️ 💾 ✈️ 🔍 💻 ⚡ 🚀 🌙 🐕 🦖 🧊 🪝 🫧 🛼 🧲 — the newer ones (🪝 🫧 🛼 🧲 🪟 🩹) are missing from older emoji fonts and will render as tofu.

No other assets. No images, icons, or illustrations.

## Files
- `moji Social Templates.dc.html` — all six artboards on one canvas. Open it in a browser to see the target. Each artboard is marked with `data-screen-label` ("01 Announcement" … "06 Big number"). Three toggles in the file's logic control review scaffolding: `showScatter`, `showFooter`, `showCaptions` — captions and the page background are review-only, as noted above.
